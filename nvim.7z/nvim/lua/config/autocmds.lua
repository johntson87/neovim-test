print("hello from autocmds")
