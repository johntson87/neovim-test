require("config.options")
require("config.globals")
require("config.remaps")

require("autocmds")

require("config.lazy")
