print("hello from autocmd lsp config")
