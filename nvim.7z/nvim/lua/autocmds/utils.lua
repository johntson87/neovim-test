-- ================================================================================================
-- TITLE : auto-commands
-- ABOUT : automatically run code on defined events (e.g. save, yank)
-- ================================================================================================

local augroup = vim.api.nvim_create_augroup
local autocmd = vim.api.nvim_create_autocmd


-- Highlight the yanked text for 300ms
local utils_auto_group = augroup("UtilsAutoGroup", {})

autocmd("TextYankPost", {
    group = utils_auto_group,
    pattern = "*",
    callback = function()
        vim.hl.on_yank({
            higroup = "IncSearch",
            timeout = 300,
        })
    end,
})
