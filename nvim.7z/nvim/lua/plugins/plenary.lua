return {
    "nvim-lua/plenary.nvim",
    name = "plenary"
}
