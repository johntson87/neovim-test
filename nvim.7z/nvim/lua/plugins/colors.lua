function ColorMyPencils(color)
    color = color or "rose-pine-moon"
    vim.cmd.colorscheme(color)
end

return {
    {
        "rose-pine/neovim",
        name = "rose-pine",
        config = function ()
            require("rose-pine").setup({
                dark_variant = "moon",
                disable_background = true,

                enable = {
                    terminal = true,
                    legacy_highlights = true,
                    migrations = true
                },

                styles = {
                    bold = true,
                    italic = false,
                    transparency = false
                }
            })

            ColorMyPencils()
        end
    },

    {
        "vague2k/vague.nvim",
        name = "vague",
        config = function()
            require("vague").setup({
                transparent = true
            })

            --ColorMyPencils("vague")
        end
    }
}
