return {
    "neovim/nvim-lspconfig",
    dependencies = {
        "stevearc/conform.nvim",
        "mason-org/mason.nvim"
    },
    config = function()
        require("conform").setup({})
        require("mason").setup({})
    end
}
