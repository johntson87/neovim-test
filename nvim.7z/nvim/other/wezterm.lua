-- Pull in the wezterm API
local wezterm = require "wezterm"

-- This will hold the configuration.
local config = wezterm.config_builder()

local theme = require("lua/rose-pine").moon

-- This is where you actually apply your config choices.

-- For example, changing the initial geometry for new windows:
config.initial_cols = 120
config.initial_rows = 28

-- or, changing the font size and color scheme.
config.font_size = 17
config.font = wezterm.font {
    family = "Cascadia Code",
    weight = "DemiBold",
    stretch = "Normal",
    style = "Normal"
}

--selection_fg = "none",
--selection_bg = "rgba(50%, 50%, 50%, 50%)"

config.colors = theme.colors()
config.enable_scroll_bar = true
config.window_background_opacity = 0.9

config.default_cwd = "c:\\Users\\samasawa\\dev"
config.default_prog = { "c:\\Users\\samasawa\\dev\\programs\\git-v2.50.1\\bin\\bash.exe" }

-- Finally, return the configuration to wezterm:
return config
